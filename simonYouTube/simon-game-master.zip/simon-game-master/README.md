# Simon Game

This is a simon game. The code goes along with my Simon game tutorial on YouTube.

Do you want to learn more about full-stack web development? Check out the completely free curriculum at www.freecodecamp.org. Anyone can learn to code for free!
